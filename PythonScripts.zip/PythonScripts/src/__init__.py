from pathlib import Path

SRC_DIR = Path(__file__).resolve().parent